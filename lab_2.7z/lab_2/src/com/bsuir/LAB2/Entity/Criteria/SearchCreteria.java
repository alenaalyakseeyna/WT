package com.bsuir.LAB2.Entity.Criteria;

import java.util.ArrayList;

public final class SearchCreteria
{
    public static String[] OvenCreteria = {"PowerConsumption","Weight","Capacity","Depth","Height","Width"};
    public static String[] Laptop = {};
    public static String[] Refrigerator = {};
    public static String[] Speakers = {};
    public static String[] TablePC = {};
    public static String[] VacuumCleaner = {};

}
