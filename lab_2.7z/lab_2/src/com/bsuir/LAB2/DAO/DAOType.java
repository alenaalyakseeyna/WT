package com.bsuir.LAB2.DAO;

/**
 * listing all types of DAOs
 */
public enum DAOType
{
    DAO,NEDAO
}
